package admin_user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import admin_user.model.Questions;
import admin_user.model.QuestionsForm;
import admin_user.model.Response;
import admin_user.service.QuestionService;
import admin_user.service.ResponseService;

@RestController
@RequestMapping("admin-page")
public class AdminController {
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	ResponseService responseService;
	
	@GetMapping("allQuestions")
    public ResponseEntity<List<Questions>> getAllQuestions(){
        return questionService.getAllQuestions();
    }
	
	/*@GetMapping("category/{category}")
	public ResponseEntity<List<Questions>> getQuestionsByCategory(@PathVariable String category){
		
	    return questionService.getQuestionsByCategory(category);
	    
	}*/
	
	@GetMapping("category/{category}")
	public ResponseEntity<String> displayQuestionsByCategory(@PathVariable String category, Model model) {
	    ResponseEntity<List<Questions>> response = questionService.getQuestionsByCategory(category);
	    
	    if (response.getStatusCode() == HttpStatus.OK) {
	        List<Questions> questions = response.getBody();
	        model.addAttribute("categoryName", category);
	        model.addAttribute("questions", questions);
	        return ResponseEntity.ok("questionByCategory"); // Return the name of the HTML template
	    } else {
	        // Handle the case when there is an error, for example, return an error template or a different HTTP status.
	        return ResponseEntity.status(response.getStatusCode()).body("Error occurred");
	    }
	}
	/*
	@RequestMapping("add")
    public String showAddQuestionForm(Model model) {
        // Assuming you have a QuestionsForm or similar DTO class to use in your form
        QuestionsForm questionsForm = new QuestionsForm();
       /* Response response = new Response();
        response.setId(questionsForm.getId());
        response.setResponse(questionsForm.getRightAnswer());*/
     /*   model.addAttribute("questionsForm", questionsForm);
        return "add"; // Return the name of the HTML template
    }*/
	
	@RequestMapping("/add")
    public ResponseEntity<String> addQuestion(@RequestBody Questions question,@ModelAttribute QuestionsForm questionsForm, Model model){
		//QuestionsForm questionsForm = new QuestionsForm();
		
		Response response = new Response();
		
		response.setResponse(question.getRightAnswer());
		response.setQuestId(question.getId());
		responseService.saveResponse(response);
		
		model.addAttribute(response);
        model.addAttribute("questionsForm", questionsForm);
        return questionService.addQuestion(question);
    }
	
}
